function [X, l, lnpdf_prior, AcceptRate, smcsettings, filtersettings] = MoveSet(X, prior_param,...
    lnpdf_prior, l, Y, gamma, smcsettings, filtersettings)

% function assumes an equal-weighted param set

Nparam  = size(X,1);

if strcmp(smcsettings.proposal,'RW')
    
    %normal random walk proposal
    % use exponential transformations for smcsettings.expindex params to
    % keep them positive
    % use logistic transformations for smcsettings.logisticndex params to
    % keep them in a bounded domain
    
    X_proposal=X;
    
    [X_proposal(:,prior_param.estindex),logprop_orig,logprop_proposal]=...
        SimProposalTrRWNormal(X(:,prior_param.estindex),smcsettings.expindex,...
        smcsettings.logisticindex,...
        smcsettings.logisticbound_l,smcsettings.logisticbound_u,smcsettings.scale);
    
    %prior likelihood at proposal
    lnpdf_prior_proposal = PriorLogl(X_proposal, prior_param);
    
elseif strcmp(smcsettings.proposal,'MixtureNormal')
    
    Nrep = 100;
    
    X_proposal = repmat(X,Nrep,1);
    
    [X_proposal(:,prior_param.estindex),logprop_orig,logprop_proposal]=...
        SimProposalTrMixtureNormal(X(:,prior_param.estindex),smcsettings.expindex,...
        smcsettings.logisticindex,smcsettings.logisticbound_l,...
        smcsettings.logisticbound_u,smcsettings.mixturedim,Nrep);
    
    %prior likelihood at proposal
    lnpdf_prior_proposal = PriorLogl(X_proposal, prior_param);
    
    keep = find(isfinite(lnpdf_prior_proposal));
    
    keep = keep(1:Nparam);
    
    X_proposal = X_proposal(keep, :);
    
    lnpdf_prior_proposal = lnpdf_prior_proposal(keep);
    logprop_proposal     = logprop_proposal(keep);
    
else
    
    error('Unknown Proposal Distribution in Move Step');
    
end

l_proposal = -inf*ones(Nparam,1);

keep = find(isfinite(lnpdf_prior_proposal));

[l_proposal(keep), filtersettings] = ...
    feval(filtersettings.filterfun, X_proposal(keep,:), Y, filtersettings); 
 
%compute acceptance weights
logtargetn_proposal = l_proposal*gamma + lnpdf_prior_proposal;

j = imag(logtargetn_proposal) ~= 0;

logtargetn_proposal(j) = -inf;

logtargetn_orig = l*gamma + lnpdf_prior;

lnalpha = logtargetn_proposal - logtargetn_orig + logprop_orig - logprop_proposal;

logu = log(rand(Nparam, 1));

accept = find(logu < lnalpha);

AcceptRate = length(accept)/Nparam;

if smcsettings.verbose
    disp(['Acceptance rate in MH step is ' num2str(AcceptRate) ]);
end

%adapt scale of proposal if necessary
if strcmp(smcsettings.proposal,'RW')
    
    if smcsettings.adaptproposalscale
        
        if AcceptRate<.2
            smcsettings.scale=smcsettings.scale*.75;
        elseif AcceptRate>.4
            smcsettings.scale=smcsettings.scale/.75;
        end
        
    end
    
end

X(accept, :) = X_proposal(accept, :);

l(accept) = l_proposal(accept);

lnpdf_prior(accept) = lnpdf_prior_proposal(accept);

end

