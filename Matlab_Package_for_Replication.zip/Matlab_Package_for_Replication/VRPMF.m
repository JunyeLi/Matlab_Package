function [VRP1, VRP2, date] = VRPMF(spx_rv, vs_spx_vix)

% volatility forecasting and non-parametric variance risk premium measure

date1 = spx_rv(:, 1);
date2 = vs_spx_vix(:, 1);

[Date, AI, BI] = intersect(date1, date2);

T = size(Date, 1);

spx_rv = spx_rv(AI, :);
vs_spx_vix = vs_spx_vix(BI, :);

% annualized realized variance and VIX-squared
RV2  = spx_rv(:, 2)*252;
VIX2 = (vs_spx_vix(:, end)/100).^2;

%plot([RV2, VIX2])

% volatility forecasting: one-month (21-day) ahead expected realized
% variance

h = 21;

RV2F = zeros(T-h+1, 1);

for t = h:T
    RV2F(t-h+1) = mean(RV2(t-h+1:t));  
end

% forecasting regressions: use two different sets of regressors
X1 = RV2(1:T-h+1);
X2 = [X1, VIX2(1:T-h+1)];

% forecasting model 1: yh = alpha + beta * X1 + e
% forecasting model 2: yh = alpha + beta * X2 + e
disp('Volatility Forecasting Regressions')
lm1 = fitlm(X1, RV2F, 'linear')
lm2 = fitlm(X2, RV2F, 'linear')

ERV1 = [ones(size(RV2)), RV2]*lm1.Coefficients.Estimate;
ERV2 = [ones(size(RV2)), RV2, VIX2]*lm2.Coefficients.Estimate;

VRP1 = ERV1 - VIX2;
VRP2 = ERV2 - VIX2;
%%
date = 2001:(2015.15-2001)/(T-1):2015.15;
% figure(1)
% plot(date, VRP1); hold on
% plot(date, VRP2, '--r')
% axis([2001, 2015.2, -0.40, 0.30])
% set(gca,'xtick', 2001:2:2015);
% set(gca,'ytick', -0.40:0.10:0.30);
% title('Non-Parametric Measures of VRP', 'FontWeight', 'normal');
% legend('VRPNP1', 'VRPNP2')

% summary statistics
rv  = sqrt(RV2);
vix = sqrt(VIX2);
disp(' ')
disp('Summary Statistics: Realized Vol, VIX, and VRPNP')
disp([mean(rv), std(rv), min(rv), max(rv), skewness(rv), kurtosis(rv);
      mean(vix), std(vix), min(vix), max(vix), skewness(vix), kurtosis(vix)])
disp([mean(VRP1), std(VRP1), min(VRP1), max(VRP1), skewness(VRP1), kurtosis(VRP1);
      mean(VRP2), std(VRP2), min(VRP2), max(VRP2), skewness(VRP2), kurtosis(VRP2)])
