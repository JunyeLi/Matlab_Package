% Monte Carlo Simulations on Parameters
%Eperiment to Compare QMC and Exact Filters: Fulop and Li (2015)

clc;
clear;
close all;

%% Simulation Setup
randn('state', 0);
rand('state', 0);

Model = 1; % 1 for non-affine self-exciting; 3 for affine self-exciting

%% true parameters
% drift
parstruct.mu = 0.04;

if Model == 1
    
    % Vol equation
    parstruct.kappa  = 6.00;
    parstruct.thetaV = 0.01;
    parstruct.sigma  = 2.50;
    parstruct.muV    = 0.010;
    parstruct.muVQ   = 0.015;
    parstruct.xi1    = 2.00;
    
    % lambda equation
    parstruct.kappaLambda = 2.00;
    parstruct.thetaLambda = 3.00;
    parstruct.sigmaLambda = 0.60;
    parstruct.beta        = 1.50;
    parstruct.xi2         = 2.00;
    
    % Jump params
    parstruct.muJ    = -0.015;
    parstruct.muJQ   = -0.020;
    parstruct.sigmaJ =  0.010;
    
    % risk premia
    parstruct.gammaV      = -0.50;%-0.5%-0.05
    parstruct.gammaLambda = -0.50;%-0.3
    
elseif Model == 3
    
    % Vol equation
    parstruct.kappa  = 10.0;
    parstruct.thetaV = 0.01;
    parstruct.sigma  = 0.30;
    parstruct.muV    = 0.02;
    parstruct.muVQ   = 0.03;
    parstruct.xi1    = 1.00;
    
    % lambda equation
    parstruct.kappaLambda = 2.50;
    parstruct.thetaLambda = 2.00;
    parstruct.sigmaLambda = 2.50;
    parstruct.beta        = 2.00;
    parstruct.xi2         = 1.00;
    
    % Jump params
    parstruct.muJ    = -0.015;
    parstruct.muJQ   = -0.020;
    parstruct.sigmaJ =  0.010;
    
    % risk premia
    parstruct.gammaV      = -8.00;%-0.5%-0.05
    parstruct.gammaLambda = -0.05;%-0.3
    
end

% leverage
parstruct.rho  = -0.85;

% maturities
tau  = [1/12, 6/12, 12/12];
N_VS = length(tau);

%measurement error
parstruct.sigmav = 0.002*ones(size(tau));

%% data simulation
Nsim = 50;
T    = 2000;

dt = 1/252; % daily frequency

simflag = 0; 

if simflag == 1
    lnS0    = log(100);
    V0      = parstruct.thetaV;
    lambda0 = parstruct.thetaLambda;
    
    % set data structure
    for i = 1:Nsim  
        [lnS, VS, Vpath, Lambdapath, NJumppath, VJump] = SimModel_linmeas(parstruct, lnS0, V0, lambda0, T, dt, tau);
        
        Y(i).lnS = lnS;
        Y(i).VS  = VS;
    end
    save Y_Experiment3 Y;
else
    load Y_Experiment3;
end

%% ---------------- implement estimation ----------------------------------
% -------------------------------------------------------------------------
M         = 1024;      % the number of state particles
Nparam    = 1024;      % the number of parameter particles
M_initial = 128;       % initial M for CRN case

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% settings of smc routine %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
smcsettings.AcceptRateBound = 2;
smcsettings.ESS_bound = Nparam/2;
smcsettings.verbose   = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  set filter settings    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
filterindx = 0
% 0 for QMC CRN, with changing M
% 1 for QMC
% 2 for exact filter
% 3 for smooth CRN, with changing M

switch filterindx
    case 0
        filtersettings.filterfun = 'LoglFun_qmc_crn';
    case 1  % QMC CRN PF
        filtersettings.filterfun = 'LoglFun_qmc';
    case 2
        filtersettings.filterfun = 'LoglFun_exact';
    case 3 
        filtersettings.filterfun = 'LoglFun_smooth_crn';
end

filtersettings.dt  = dt;
filtersettings.tau = tau;

if filterindx == 0 || 3 
    
    filtersettings.M_initial = M_initial;
    filtersettings.M_final   = M;
    
elseif filterindx == 1 || 2
    filtersettings.M = M;
end

filtersettings.nt     = 64;
filtersettings.nb     = 256;
filtersettings.nt_rng = 64;
filtersettings.nb_rng = 256;
filtersettings.offset = 0;
filtersettings.seeds  = [1 2 3 1 2 3];

% initial state variables
filtersettings.V0      = 0.01;
filtersettings.lambda0 = 3.00;

filtersettings.qmc_set = sobolset(4);

filtersettings.burnin  = 10; %burnin needs to be 0 in sequential algorithm!!!!
filtersettings.N_VS    = N_VS;

filtersettings.param_fields = {'mu', 'kappa',  'kappaLambda', 'thetaV',...
                               'thetaLambda', 'sigma', 'sigmaLambda',...
                               'xi1','xi2', 'muV', 'muVQ', 'beta',...
                               'muJ', 'sigmaJ', 'muJQ', 'rho', 'gammaV',...
                               'gammaLambda', 'sigmav'};

% (Truncated) normal priors for model parameters
prior_param.mu  = [0.04,  8.00, 8.00,  0.02,  2.00,  2.00,  5.00, 2.00, 2.00, 0.05, 0.05,...
                   2.00, -0.01, 0.02, -0.02, -0.70, -6.00, -1.50, 0.002];

prior_param.sig = [0.01,  15.0, 15.0,  0.10,  8.00,  8.00,  15.0, 1e-8, 1e-8, 0.10, 0.10,...
                   5.00,  0.15, 0.15,  0.15,  0.80,  15.0,  5.00, 0.002];

prior_param.estindex = [1:7, 10:11, 12, 13:19]'; % model 1CEV

expindex = [2:12, 14, 19];

[ph, ph2, expindex]  = intersect(expindex, prior_param.estindex);
smcsettings.expindex = expindex;

smcsettings.logisticindex   = [];
smcsettings.logisticbound_l = [];
smcsettings.logisticbound_u = [];

%'MixturNormal' or 'RW'
smcsettings.proposal = 'MixtureNormal';
%smcsettings.proposal='RW';

%this option is only used if MixtureNormal proposal is used
smcsettings.mixturedim = 6;

%these options are only used if RW proposal is used
%smcsettings.adaptproposalscale=1;
%smcsettings.scale=1;

runEst = 0; % 1 for running estimation, otherwise, report the results

if runEst == 1
    % run Routine
    for i = 1:Nsim
        i
        
        if filterindx == 0
            
            filtersettings.randshift = rand(4, T);
            
            [res(i), res_final(i), filtersettings] = RunEst_ChangeM(prior_param, Nparam, Y(i), filtersettings, smcsettings);
            
            save MC_res_Experiment3_QMC_CRN res res_final filtersettings smcsettings prior_param;
            
        elseif filterindx == 3
            
            filtersettings.randu_set = rand(M, T, 4);
            
            [res(i), res_final(i), filtersettings] = RunEst_ChangeM(prior_param, Nparam, Y(i), filtersettings, smcsettings);
            
            save MC_res_Experiment3_Smooth_CRN res res_final filtersettings smcsettings prior_param;
            
        elseif filterindx == 1
            
            [res(i), filtersettings] = RunEst(prior_param, Nparam, Y(i), filtersettings, smcsettings);
            
            save MC_res_Experiment3_QMC res filtersettings smcsettings prior_param;
            
        elseif filterindx == 2
            
            [res(i), filtersettings] = RunEst(prior_param, Nparam, Y(i), filtersettings, smcsettings);
            
            save MC_res_Experiment3_Exact res filtersettings smcsettings prior_param;
        end
        
    end
    
else
    %% Now report simulation results
    % load results
    %%%%%%%%% Exact-PF-PM
    load MC_res_Experiment3_Exact
    
    paramMC1   = [];
    runtimeMC1 = [];
    
    for i = 1:Nsim
        
        param    = res(i).Xm(end, :);
        paramMC1 = [paramMC1; param];
        
        runtimeMC1 = [runtimeMC1; res(i).runtime(end)];
        
    end
    
    %%%%%%%% QMC-PF-PM
    load MC_res_Experiment3_QMC
    
    paramMC2   = [];
    runtimeMC2 = [];
    
    for i = 1:Nsim
        
        param    = res(i).Xm(end, :);
        paramMC2 = [paramMC2; param];
        
        runtimeMC2 = [runtimeMC2; res(i).runtime(end)];
        
    end
    
    % Smooth PF, CRN
    load MC_res_Experiment3_Smooth_CRN
    
    paramMC3   = [];
    runtimeMC3 = [];
    
    for i = 1:Nsim
        
        param    = res_final(i).Xm(end, :);
        paramMC3 = [paramMC3; param];
        
        runtimeMC3 = [runtimeMC3; [res(i).runtime(end), res_final(i).runtime(end)]];
        
    end
    
    %%%%% QMC-PF-CRN
    load MC_res_Experiment3_QMC_CRN
    
    paramMC4   = [];
    runtimeMC4 = [];
    
    for i = 1:Nsim
        
        param    = res_final(i).Xm(end, :);
        paramMC4 = [paramMC4; param];
        
        runtimeMC4 = [runtimeMC4; [res(i).runtime(end), res_final(i).runtime(end)]];
        
    end
    
    % true parameter values
    K = length(filtersettings.param_fields);
    paramTR = zeros(1, K);
    for i = 1:K-1
        paramTR(:, i) = parstruct.(filtersettings.param_fields{i});
    end
    paramTR(:, end) = parstruct.sigmav(1);
    
    paramTR = ones(Nsim, 1)*paramTR;
    
    ErrMC1 = paramMC1 - paramTR;
    ErrMC2 = paramMC2 - paramTR;
    ErrMC3 = paramMC3 - paramTR;
    ErrMC4 = paramMC4 - paramTR;
    
    MeanMC1 = mean(paramMC1);
    MeanMC2 = mean(paramMC2);
    MeanMC3 = mean(paramMC3);
    MeanMC4 = mean(paramMC4);
    
    RmseMC1 = sqrt(mean(ErrMC1.^2));
    RmseMC2 = sqrt(mean(ErrMC2.^2));
    RmseMC3 = sqrt(mean(ErrMC3.^2));
    RmseMC4 = sqrt(mean(ErrMC4.^2));
    
    disp('Mean and RMSE')
    disp([paramTR(1, :)', [MeanMC1; RmseMC1]', [MeanMC2; RmseMC2]', [MeanMC3; RmseMC3]', [MeanMC4; RmseMC4]'])
    
    disp('Average Computational Cost')
    disp([mean(runtimeMC1) mean(runtimeMC2) sum(mean(runtimeMC3)) sum(mean(runtimeMC4))]/3600)
    
end