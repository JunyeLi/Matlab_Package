function [l, filtersettings, Particles] = LoglFun_smooth_crn(X, Y, filtersettings)

Nparam = size(X, 1);

M = filtersettings.M;

% set param input to cuda pf
for i = 1:length(filtersettings.param_fields) - 1
    param.(filtersettings.param_fields{i}) = X(:, 1); X = X(:, 2:end);
end

param.sigmav = X*ones(1, filtersettings.N_VS);

Particles.muStates = repmat([filtersettings.V0, filtersettings.lambda0], Nparam, 1);
Particles.VStates  = zeros(Nparam, 2, 2);
Particles.VStates(:, 1, 1) = 1e-10;
Particles.VStates(:, 2, 2) = 1e-10;

N_VS = filtersettings.N_VS;

FilterName = ['PF_cuda_Smooth_crn_' num2str(N_VS) 'VS'];

[l, Particles] = feval(FilterName, param, Particles, Y.lnS, Y.VS,...
                        filtersettings.nt, filtersettings.nb, filtersettings.dt,...
                        filtersettings.tau, M, filtersettings.randu_set); 
                    
l = sum(l(:, filtersettings.burnin+1:end), 2);

l(~isfinite(l)) = -inf;
