function [paramP, paramQ] = SetParam(X, filtersettings)

% filtersettings.param_fields = {'mu', 'kappa',  'kappaLambda', 'thetaV',...
%                                'thetaLambda', 'sigma', 'sigmaLambda',...
%                                'xi1','xi2', 'muV', 'muVQ', 'beta',...
%                                'muJ', 'sigmaJ', 'muJQ', 'rho', 'gammaV',...
%                                'gammaLambda', 'sigmav'};

M = 1;%filtersettings.M;

for i = 1:length(filtersettings.param_fields) - 1
        param.(filtersettings.param_fields{i}) = repmat(X(:, 1), M, 1); X = X(:, 2:end);
end

paramP.kappa       = param.kappa;
paramP.kappaLambda = param.kappaLambda;
paramP.theta       = param.thetaV;
paramP.thetaLambda = param.thetaLambda;
paramP.muV         = param.muV;
paramP.beta        = param.beta;
paramP.muJ         = param.muJ;
paramP.sigmaJ      = param.sigmaJ;

paramQ.kappa       = param.kappa + param.sigma.*param.gammaV;
paramQ.kappaLambda = param.kappaLambda + param.sigmaLambda.*param.gammaLambda;
paramQ.theta       = param.kappa.*param.thetaV./paramQ.kappa;
paramQ.thetaLambda = param.kappaLambda.*param.thetaLambda./paramQ.kappaLambda;
paramQ.muV         = param.muVQ;
paramQ.beta        = param.beta;
paramQ.muJ         = param.muJQ;
paramQ.sigmaJ      = param.sigmaJ;


