function [A, B, C, A1, A2, A3, C1, C2] = VS_Components(parstruct, tau)

M = length(tau);

lambda_bar = parstruct.kappaLambda.*parstruct.thetaLambda./(parstruct.kappaLambda - parstruct.beta);

H = (1 - exp(-(parstruct.kappaLambda - parstruct.beta)*tau))./((parstruct.kappaLambda - parstruct.beta)*tau);

B = (1 - exp(-parstruct.kappa*tau))./(parstruct.kappa*tau);

C1 = -(parstruct.muV*ones(1, M)).*(H - B)./((parstruct.kappaLambda - parstruct.beta - parstruct.kappa)*ones(1, M));

C2 = ((parstruct.muJ.^2 + parstruct.sigmaJ.^2)*ones(1, M)).*H;

C = C1 + C2;

A1 = (1 - B).*(parstruct.theta*ones(1, M));

A2 = ((parstruct.muJ.^2 + parstruct.sigmaJ.^2)*ones(1, M)).*(1 - H).*(lambda_bar*ones(1, M));

A3 = (parstruct.muV*ones(1, M)).*( (1 - B)./(parstruct.kappa*ones(1, M)) + (H - B)./((parstruct.kappaLambda...
     - parstruct.beta - parstruct.kappa)*ones(1, M)) ).*(lambda_bar*ones(1, M));

A = A1 + A2 + A3;


