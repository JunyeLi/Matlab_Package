function lnS_mean = MeasEquation_lnS(lnSold, dt, parstruct, oldV, oldLambda, NJumps, z_VPts)

kJ1 = exp(parstruct.muJ + parstruct.sigmaJ.^2/2) - 1;

drift = parstruct.mu - 0.5.*oldV - kJ1.*oldLambda;

lnS_mean = lnSold + drift*dt + NJumps.*parstruct.muJ + oldV.^(.5).*parstruct.rho.*z_VPts;
