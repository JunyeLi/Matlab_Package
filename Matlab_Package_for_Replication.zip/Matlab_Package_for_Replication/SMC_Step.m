function [ESS, normfac, AcceptRate, X, l, lnw, lnpdf_prior, gamma, smcsettings, filtersettings] =...
                 SMC_Step(X, l, lnw, lnpdf_prior, prior_param, gamma,...
                 Y,smcsettings, filtersettings)

% one step of the sequential SMC algorithm
AcceptRate = nan;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%do branching out:                              %
%1: process new observation by running PF on it %
%2: attach weights                              %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

gammavec = linspace(-100, 0, 1000);

ESSvec = TempFun(gammavec, lnw, l);


j = find(ESSvec < smcsettings.ESS_bound);

if ~isempty(j)
    
    gammaincrement = gammavec(j(1));
    
    gammanew = min(gamma+exp(gammaincrement),1);
    
elseif min(ESSvec) > smcsettings.ESS_bound
    
    gammanew = 1;
    
end

incrementalw = (gammanew - gamma)*l;

j = find(isnan(incrementalw) | imag(incrementalw) ~=0);

incrementalw(j) = -inf;

% get incremental normalizing ratio
W_prev = exp(lnw - max(lnw)); W_prev = W_prev/sum(W_prev);

max_incrementalw = max(incrementalw);

normfac = log(sum(W_prev.*exp(incrementalw-max_incrementalw))) + max_incrementalw;
%end of normalizing ratio computations

lnw = lnw + incrementalw;

%compute normalized weights and compute ESS
W = exp(lnw - max(lnw));

W = W/sum(W);

ESS = 1/sum(W.^2);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  always run resample and move    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if smcsettings.verbose
    disp(['Resample and Move at gamma = ' num2str(gammanew)]);
end
%%%%%%%%%%
%Resample%
%%%%%%%%%%

[X, lnw, l, lnpdf_prior] = ResampleSet(X, lnw, l, lnpdf_prior);

counter = 0;

cont = 1;

sumAccept=0;

while cont
    
    counter = counter + 1;
    
    [X, l, lnpdf_prior, AcceptRate, smcsettings, filtersettings] = MoveSet(X, prior_param,...
       lnpdf_prior, l, Y,gammanew, smcsettings, filtersettings);
          
    sumAccept = sumAccept + AcceptRate;
                   
    if smcsettings.verbose
        disp(['cumulative acceptance rate after move # ' num2str(counter) ' : ' num2str(sumAccept)]);
    end
    
    cont = sumAccept < smcsettings.AcceptRateBound;
end

gamma = gammanew;
