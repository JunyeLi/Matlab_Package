% Monte Carlo Simulations on Parameters
% Experiment to Compare QMC and Exact Filters: Fulop and Li (2015)

clc;
clear;
close all;

%% Simulation Setup
randn('state', 0);
rand('state', 0);

Model = 1; % 1 for non-affine self-exciting; 3 for affine self-exciting

%% true parameters
% drift
parstruct.mu = 0.04;

if Model == 1
    
    % Vol equation
    parstruct.kappa  = 6.00;
    parstruct.thetaV = 0.01;
    parstruct.sigma  = 2.50;
    parstruct.muV    = 0.010;
    parstruct.muVQ   = 0.015;
    parstruct.xi1    = 2.00;
    
    % lambda equation
    parstruct.kappaLambda = 2.00;
    parstruct.thetaLambda = 3.00;
    parstruct.sigmaLambda = 0.60;
    parstruct.beta        = 1.50;
    parstruct.xi2         = 2.00;
    
    % Jump params
    parstruct.muJ    = -0.015;
    parstruct.muJQ   = -0.020;
    parstruct.sigmaJ =  0.010;
    
    % risk premia
    parstruct.gammaV      = -0.50;%-0.5%-0.05
    parstruct.gammaLambda = -0.50;%-0.3
    
elseif Model == 3
    
    % Vol equation
    parstruct.kappa  = 10.0;
    parstruct.thetaV = 0.01;
    parstruct.sigma  = 0.30;
    parstruct.muV    = 0.02;
    parstruct.muVQ   = 0.03;
    parstruct.xi1    = 1.00;
    
    % lambda equation
    parstruct.kappaLambda = 2.50;
    parstruct.thetaLambda = 2.00;
    parstruct.sigmaLambda = 2.50;
    parstruct.beta        = 2.00;
    parstruct.xi2         = 1.00;
    
    % Jump params
    parstruct.muJ    = -0.015;
    parstruct.muJQ   = -0.020;
    parstruct.sigmaJ =  0.010;
    
    % risk premia
    parstruct.gammaV      = -8.00;%-0.5%-0.05
    parstruct.gammaLambda = -0.05;%-0.3
    
end

% leverage
parstruct.rho  = -0.85;

% maturities
tau  = [1/12, 6/12, 12/12];
N_VS = length(tau);

%measurement error
parstruct.sigmav = 0.002*ones(size(tau));

%% data simulation
Nsim = 1;
T    = 2000;

dt = 1/252; % daily frequency

simflag = 0; %use same data set as in experiment 1

if simflag == 1
    lnS0    = log(100);
    V0      = parstruct.thetaV;
    lambda0 = parstruct.thetaLambda;
    
    % set data structure
    for i = 1:Nsim  
        [lnS, VS, Vpath, Lambdapath, NJumppath, VJump] = SimModel_linmeas(parstruct, lnS0, V0, lambda0, T, dt, tau);
        
        Y(i).lnS = lnS;
        Y(i).VS  = VS;
    end
    save Y_Experiment1 Y;
else
    load Y_Experiment1;
end

%% ---------------- implement estimation ----------------------------------
% -------------------------------------------------------------------------
M_initial = 128;
M         = 1024;      % the number of state particles
Nparam    = 1024;      % the number of parameter particles

%%%%%%%%%%%%%%%%%%%%%%%%%%%
% settings of smc routine %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
smcsettings.AcceptRateBound = 2;
smcsettings.ESS_bound = Nparam/2;
smcsettings.verbose   = 1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  set filter settings    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%
filterindx = 0
% 0 for QMC CRN
% 1 for QMC
% 2 for exact filter
% 3 for smooth PF CRN

switch filterindx
    case 0
        filtersettings.filterfun = 'LoglFun_qmc_crn';
    case 1 
        filtersettings.filterfun = 'LoglFun_qmc';
    case 2
        filtersettings.filterfun = 'LoglFun_exact';
    case 3
        filtersettings.filterfun = 'LoglFun_smooth_crn';
end

filtersettings.dt  = dt;
filtersettings.tau = tau;

if filterindx == 0 || 3
    
    filtersettings.M_initial = M_initial;
    filtersettings.M_final   = M;
    
elseif filterindx == 1 || 2
    filtersettings.M = M;
end

filtersettings.nt     = 64;
filtersettings.nb     = 256;
filtersettings.nt_rng = 64;
filtersettings.nb_rng = 256;
filtersettings.offset = 0;
filtersettings.seeds  = [1 2 3 1 2 3];

% initial state variables
filtersettings.V0      = 0.01;
filtersettings.lambda0 = 3.00;

filtersettings.qmc_set = sobolset(4);

filtersettings.burnin  = 10; %burnin needs to be 0 in sequential algorithm!!!!
filtersettings.N_VS    = N_VS;
filtersettings.param_fields = {'mu', 'kappa',  'kappaLambda', 'thetaV',...
                               'thetaLambda', 'sigma', 'sigmaLambda',...
                               'xi1','xi2', 'muV', 'muVQ', 'beta',...
                               'muJ', 'sigmaJ', 'muJQ', 'rho', 'gammaV',...
                               'gammaLambda', 'sigmav'};

% (Truncated) normal priors for model parameters
prior_param.mu  = [0.04,  8.00, 8.00,  0.02,  2.00,  2.00,  5.00, 2.00, 2.00, 0.05, 0.05,...
                   2.00, -0.01, 0.02, -0.02, -0.70, -6.00, -1.50, 0.002];

prior_param.sig = [0.01,  15.0, 15.0,  0.10,  8.00,  8.00,  15.0, 1e-8, 1e-8, 0.10, 0.10,...
                   5.00,  0.15, 0.15,  0.15,  0.80,  15.0,  5.00, 0.002];

prior_param.estindex = [1:7, 10:11, 12, 13:19]'; % model 1CEV

expindex = [2:12, 14, 19];

[ph, ph2, expindex]  = intersect(expindex, prior_param.estindex);
smcsettings.expindex = expindex;

smcsettings.logisticindex   = [];
smcsettings.logisticbound_l = [];
smcsettings.logisticbound_u = [];

%'MixturNormal' or 'RW'
smcsettings.proposal = 'MixtureNormal';
%smcsettings.proposal='RW';

%this option is only used if MixtureNormal proposal is used
smcsettings.mixturedim = 6;

%these options are only used if RW proposal is used
%smcsettings.adaptproposalscale=1;
%smcsettings.scale=1;
% run Routine
Nsim = 20;

runEst = 0;

if runEst == 1
    
    for i = 1:Nsim
        i
        
        if filterindx == 0
            
            filtersettings.randshift = rand(4, T);
            
            [res(i), res_final(i), filtersettings] = RunEst_ChangeM(prior_param, Nparam, Y, filtersettings, smcsettings);
            
            save MC_res_Experiment1_QMC_CRN res res_final filtersettings smcsettings prior_param;
            
        elseif filterindx == 3
            
            filtersettings.randu_set = rand(M, T, 4);
            
            [res(i), res_final(i), filtersettings] = RunEst_ChangeM(prior_param, Nparam, Y, filtersettings, smcsettings);
            
            save MC_res_Experiment1_Smooth_CRN res res_final filtersettings smcsettings prior_param;
            
        elseif filterindx == 1
            
            [res(i), filtersettings] = RunEst(prior_param, Nparam, Y, filtersettings, smcsettings);
            
            save MC_res_Experiment1_QMC res filtersettings smcsettings prior_param;
            
        elseif filterindx == 2
            
            [res(i), filtersettings] = RunEst(prior_param, Nparam, Y, filtersettings, smcsettings);
            
            save MC_res_Experiment1_Exact res filtersettings smcsettings prior_param;
        end
        
    end
    
else
    %% report results
    load MC_res_Experiment1_QMC_CRN
    
    mLLH1  = [];
    nBrdg1 = [];
    
    for i = 1:Nsim
        normf1 = sum(res(i).normfac);       iter1 = length(res(i).normfac);
        normf2 = sum(res_final(i).normfac); iter2 = length(res_final(i).normfac);
        
        mLLH1  = [mLLH1; normf1+normf2];
        nBrdg1 = [nBrdg1; [iter1, iter2]];
        
    end
    
    load MC_res_Experiment1_Smooth_CRN
    
    mLLH2  = [];
    nBrdg2 = [];
    
    for i = 1:Nsim
        normf1 = sum(res(i).normfac);       iter1 = length(res(i).normfac);
        normf2 = sum(res_final(i).normfac); iter2 = length(res_final(i).normfac);
        
        mLLH2  = [mLLH2; normf1+normf2];
        nBrdg2 = [nBrdg2; [iter1, iter2]];
        
    end
    
    load MC_res_Experiment1_QMC
    
    mLLH3  = [];
    nBrdg3 = [];
    
    for i = 1:Nsim
        normf = sum(res(i).normfac);       iter = length(res(i).normfac);
        
        mLLH3  = [mLLH3; normf];
        nBrdg3 = [nBrdg3; [iter, NaN]];
        
    end
    
    load MC_res_Experiment1_Exact
    
    mLLH4  = [];
    nBrdg4 = [];
    
    for i = 1:Nsim
        normf = sum(res(i).normfac);       iter = length(res(i).normfac);
        
        mLLH4  = [mLLH4; normf];
        nBrdg4 = [nBrdg4; [iter, NaN]];
        
    end
    
    disp('Mean and STD of Marginal Likelihood')
    disp([mean(mLLH1)/1e3, std(mLLH1);
          mean(mLLH2)/1e3, std(mLLH2);
          mean(mLLH3)/1e3, std(mLLH3);
          mean(mLLH4)/1e3, std(mLLH4)])
      
    disp('Number of Bridging Steps')
    disp([mean(nBrdg1); mean(nBrdg2); mean(nBrdg3); mean(nBrdg4)])
    
end



