function VS = PriceVS(V, Lambda, parstruct, tau)

%Ntau = length(tau);

lambda_bar = parstruct.kappaLambdaQ*parstruct.thetaLambdaQ/(parstruct.kappaLambdaQ - parstruct.beta);

H = (1 - exp(-(parstruct.kappaLambdaQ - parstruct.beta)*tau))./((parstruct.kappaLambdaQ-parstruct.beta)*tau);

B = (1 - exp(-parstruct.kappaQ*tau))./(parstruct.kappaQ*tau);

C1 = -parstruct.muVQ*(H - B)/(parstruct.kappaLambdaQ - parstruct.beta - parstruct.kappaQ);

C2 = (parstruct.muJQ^2 + parstruct.sigmaJ^2)*H;

C = C1 + C2;
                            
A1 = (1 - B )*parstruct.thetaVQ;

A2 = (parstruct.muJQ^2 + parstruct.sigmaJ^2)*(1 - H)*lambda_bar;

A3 = parstruct.muVQ*( (1 - B)/parstruct.kappaQ + (H - B)/(parstruct.kappaLambdaQ...
     - parstruct.beta - parstruct.kappaQ) )*lambda_bar;

A = A1 + A2 + A3;

VS = A + B*V + C*Lambda;

