function lnpdf_prior = PriorLogl(X, prior_param)
  
% 'mu','kappa','kappaLambda','thetaV','thetaLambda','sigma',
% 'sigmaLambda','xi1','xi2','muV','muVQ','beta','muJ','sigmaJ',...
% 'muJQ','rho','gammaV','gammaLambda','sigmav';

Nsample = size(X, 1);

E = repmat(prior_param.mu, Nsample, 1);
V = repmat(prior_param.sig, Nsample, 1);

lnpdf_prior = -(X - E).^2./(2*V.^2) - log(2*pi)/2 - log(V);

% other restrictions
kappaV  = X(:, 2);
kappaL  = X(:, 3);
kappaVQ = kappaV + X(:, 6).*X(:, 17);
kappaLQ = kappaL + X(:, 7).*X(:, 18);

%muJ  = X(:, 13);  | muJ < muJQ
%muJQ = X(:, 15);

% enforce parameters in their supports
index_p = [2:12, 14, 19];
index_n = [13, 15, 17, 18];

indx = any(X(:, index_p) < 0, 2) | any(X(:, index_n) > 0, 2) | kappaVQ < 0 | kappaLQ < 0 |...
       kappaL - X(:, 12) < 0 | X(:, 16) < -1 | X(:, 16) > 1;

lnpdf_prior(indx, :) = -inf;

lnpdf_prior = sum(lnpdf_prior(:, prior_param.estindex), 2);

