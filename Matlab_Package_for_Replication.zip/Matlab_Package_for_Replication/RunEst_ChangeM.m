function [res, res_final, filtersettings] = RunEst_ChangeM(prior_param, Nparam, Y, filtersettings, smcsettings)

% run density-tempered SMC 

% simulate from prior
X = PriorSim(prior_param, 30*Nparam);

lnpdf_prior = PriorLogl(X, prior_param);

keep = find(isfinite(lnpdf_prior));

X = X(keep(1:Nparam), :);

lnpdf_prior = lnpdf_prior(keep(1:Nparam));

filtersettings.M = filtersettings.M_initial;

% evaluate log likelihood at initial parameters
[l, filtersettings] = feval(filtersettings.filterfun, X, Y, filtersettings);

%%%%%%%%%%%%%%%%%%%%%%%%
% run smc at initial M %
%%%%%%%%%%%%%%%%%%%%%%%%

lnw = zeros(Nparam, 1);

gamma = 0;

t = 1;

tic

while (gamma < 1 )
    
    [res.ESS(t), res.normfac(t), res.AcceptRate(t,:), X, l, lnw, lnpdf_prior,...
         gamma, smcsettings,filtersettings] = SMC_Step(X, l, lnw, lnpdf_prior, prior_param,...
         gamma, Y, smcsettings, filtersettings);
           
    W = exp(lnw - max(lnw));
    
    W = W/sum(W);
    
    Xeven = Resample_vec(X, W, 10*Nparam);
    
    mean(Xeven)
    
    res.Xm(t, :) = mean(Xeven);
    
    res.X_prc5(t,:) = prctile(Xeven, 5);
    
    res.X_prc95(t,:) = prctile(Xeven, 95);
    
    res.runtime(t) = toc;

    if smcsettings.verbose    
        disp(['Time elapsed in sec ' num2str(res.runtime(t))]);
        disp(' ')
    end

    res.gamma(t) = gamma;
                    
    t = t+1;
end

%store full-sample posterior
res.X = X;
res.W = W;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%now go to higher M
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%run filter at new M
filtersettings.M = filtersettings.M_final;

[l_newM, filtersettings] = feval(filtersettings.filterfun, X, Y, filtersettings);

%now do tempered steps from old to new M

gamma = 0;

t = 1;

tic

while (gamma < 1 )
    
    [res_final.ESS(t), res_final.normfac(t), res_final.AcceptRate(t,:), X, l,l_newM, lnw, lnpdf_prior,...
         gamma, smcsettings,filtersettings] = SMC_Step_ChangeM(X, l,l_newM, lnw, lnpdf_prior, prior_param,...
         gamma, Y, smcsettings, filtersettings);
              
    W = exp(lnw - max(lnw));
    
    W = W/sum(W);
    
    Xeven = Resample_vec(X, W, 10*Nparam);
    
    mean(Xeven)
    
    res_final.Xm(t, :) = mean(Xeven);
    
    res_final.X_prc5(t,:) = prctile(Xeven, 5);
    
    res_final.X_prc95(t,:) = prctile(Xeven, 95);
    
    res_final.runtime(t) = toc;

    if smcsettings.verbose  
                
        disp(['Time elapsed in sec ' num2str(res.runtime(t))]);
        disp(' ')
    end

    res_final.gamma(t) = gamma;
                    
    t = t+1;
end

% store full-sample posterior
res_final.X = X;
res_final.W = W;









