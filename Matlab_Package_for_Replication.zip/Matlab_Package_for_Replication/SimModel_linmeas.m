function [lnS, Y, Vpath, Lambdapath, NJumppath, VJump] = SimModel_linmeas(parstruct,...
                              lnS0, V0,  Lambda0, T, dt, tau)

Vpath  = zeros(T, 1);
VJump  = zeros(T, 1);

Lambdapath = zeros(T, 1);
NJumppath  = zeros(T, 1);

lnS = zeros(T, 1);

Ntau = length(tau);
Y = zeros(T, Ntau);

Vpath(1)  = V0;
Lambdapath(1) = Lambda0;

lnS(1) = lnS0;

parstruct.kappaQ  = parstruct.kappa + parstruct.sigma*parstruct.gammaV;
parstruct.thetaVQ = parstruct.kappa*parstruct.thetaV/parstruct.kappaQ;

parstruct.kappaLambdaQ = parstruct.kappaLambda + parstruct.sigmaLambda*parstruct.gammaLambda;
parstruct.thetaLambdaQ = parstruct.kappaLambda*parstruct.thetaLambda/parstruct.kappaLambdaQ;

for t = 2:T
    
   % iterate hidden states
   % generate jump indicator
   % PrNoJump = exp(-Lambdapath(t-1)*dt);
   
   %NJumppath(t) = PrNoJump < rand;
   
   NJumppath(t) = poissrnd(Lambdapath(t-1)*dt);
              
   % brownian increment
   dz = sqrt(dt)*randn(1, 2);
   
   % generate underlying observation
   E_lnS = MeasEquation_lnS(lnS(t-1), dt, parstruct, Vpath(t-1), Lambdapath(t-1), NJumppath(t), dz(1));
      
   sig_lnS = sqrt(NJumppath(t)*parstruct.sigmaJ^2 + Vpath(t-1)*(1-parstruct.rho^2)*dt);
   
   lnS(t) = E_lnS + sig_lnS*randn;
   
   % move dynamic state variables
   if NJumppath(t) == 0
      VJump(t) = 0;
   else
      VJump(t) = sum(exprnd(parstruct.muV, NJumppath(t), 1));
   end
   
   Vpath(t)  = max(1e-10, Vpath(t-1) + parstruct.kappa*(parstruct.thetaV - Vpath(t-1))*dt...
                   + parstruct.sigma*Vpath(t-1)^(parstruct.xi1/2)*dz(1) + VJump(t));
  
   Lambdapath(t) = max(1e-10, Lambdapath(t-1) + parstruct.kappaLambda*(parstruct.thetaLambda...
                       - Lambdapath(t-1))*dt + parstruct.beta*NJumppath(t)...
                       + parstruct.sigmaLambda*Lambdapath(t-1)^(parstruct.xi2/2)*dz(2));
                   
   % compute VS observations
    Y(t, :) = PriceVS(Vpath(t), Lambdapath(t), parstruct, tau) + parstruct.sigmav.*randn(1, Ntau);
      
end
