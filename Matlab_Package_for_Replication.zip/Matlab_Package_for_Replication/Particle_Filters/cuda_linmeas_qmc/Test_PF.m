clear all

%addpath '/home/essec/Desktop/VD_VRP_SMC_Marginalized_Restricted/';

addpath 'C:\Users\Fandras\Google Drive\fulop\current_projects\Variance_Dynamics\VD_VRP_SMC_Marginalized_Restricted\';

randn('state',0);

rand('state',0);

%drift
parstruct.mu=.04;

%V equation            
parstruct.kappa=4.8;
parstruct.thetaV=0.009;
parstruct.sigma=2.7;
parstruct.muV=0.01;
parstruct.muVQ=0.01;

parstruct.xi1=2;

%lambda equation
parstruct.kappaLambda=1.2;
parstruct.thetaLambda=0.56;
parstruct.sigmaLambda=.33;
parstruct.xi2=2.2;
parstruct.beta=1.12;

%Jump params
parstruct.muJ=-.014;
parstruct.muJQ=-.016;
parstruct.sigmaJ=.02;

%leverage 
parstruct.rho=-.8;

%risk premia
parstruct.gammaV=-.08;
parstruct.gammaLambda=-.2;

tau=[1/12 6/12 12/12];

parstruct.sigmav=.005*ones(size(tau));

param_fields = {'mu', 'kappa',  'kappaLambda', 'thetaV', 'thetaLambda',...
                'sigma', 'sigmaLambda', 'xi1','xi2', 'muV', 'muVQ', 'beta',...
                'muJ', 'sigmaJ', 'muJQ', 'rho', 'gammaV', 'gammaLambda', 'sigmav'};
    
clear param0;
            
for i=1:length(param_fields)-1
    
    param0(i)=parstruct.(param_fields{i});
    
end     

param0=[param0 parstruct.sigmav];

r=.05;
dt=1/252;

lnS0=log(100);
V0=parstruct.thetaV;
lambda0=parstruct.thetaLambda;

%run PF

simflag=1;

if simflag==1
    
   T=100;
    
    [lnS, Y, Vpath, Lambdapath, NJumppath, VJump]=SimModel_linmeas(parstruct,lnS0,V0,lambda0,T,dt,tau);
    
    %Y(2,:)=Y(2,:)+[-.2 .3 .1 0];
    
    %Y(2:end,:)=Y(2:end,:)+.3*(rand(T-1,4)<.05).*randn(T-1,4);
    
else
    
 
end

% 
% for i=1:10
%     
%     i
%     
%     %still needs to code full filter for this model!
%     
%     Nparticles=64*8;
%     
%     lnweights=log(ones(Nparticles,1)/Nparticles);
%     
%     Particles.V=V0*ones(Nparticles,1);
%     Particles.lambda=lambda0*ones(Nparticles,1);
%     Particles.NJumps=zeros(Nparticles,1);
%     
%     tic
%     
%     [ph,lnweights,logl(:,i),ESS(:,i),FiltMeans(:,:,i)]=PF(param0, Particles, lnweights,lnS, Y,dt,tau);
%     
%     cputime1(i)=toc;
%     
%     
% end

% %gpu

Nparticles=2048;
Nparam     = 128;
% cuda pf settings
PFOptions.nt = 64;
PFOptions.nb = 512;

PFOptions.nt_rng = 64;
PFOptions.nb_rng = 512;

PFOptions.offset = 0;

PFOptions.seeds = [1 2 3 1 2 3];

X = repmat(param0, Nparam, 1);

% set param input to cuda pf
for i = 1:length(param_fields)-1
    param.(param_fields{i}) = X(:, 1); X=X(:,2:end);
end

param.sigmav=X;

Particles.muStates=repmat([V0 lambda0],Nparam,1);

Particles.VStates=zeros(Nparam,2,2);
Particles.VStates(:,1,1)=1e-10;
Particles.VStates(:,2,2)=1e-10;
    
p=sobolset(4);
qmc_set=p(1:Nparticles,:);

tic
[l, Particlesout, ph] = PF_cudaQMC_3VS(param, Particles, lnS, Y, PFOptions.nt,...
        PFOptions.nb, PFOptions.nt_rng, PFOptions.nb_rng, PFOptions.seeds, PFOptions.offset, dt,tau,qmc_set);
toc



Particles.NJumps=zeros(Nparam,Nparticles);
Particles.V=V0*ones(Nparam,Nparticles);
Particles.lambda=lambda0*ones(Nparam,Nparticles);
Particles.VJ=zeros(Nparam,Nparticles);
 
tic
 [l2, Particlesout2, ph] = PF_cuda_3VS(param, Particles, lnS, Y, PFOptions.nt,...
         PFOptions.nb, PFOptions.nt_rng, PFOptions.nb_rng, PFOptions.seeds, PFOptions.offset, dt,tau);
toc




