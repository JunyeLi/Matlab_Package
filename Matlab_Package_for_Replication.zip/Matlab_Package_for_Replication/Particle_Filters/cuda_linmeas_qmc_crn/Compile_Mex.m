clc;
clear;

%%%%%%%%% Important!!! Read Carefully before running this code %%%%%%%%%%%%
%%%%%%%   make sure that the directories for cuda, Matlab,  %%%%%%%%%%%%%%%
%%%%%%%   and nag_rng are all correct. %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

OS = 'Linux'; % or 'Windows'

switch OS
    case 'Linux'  
    
        !rm *.o
        
        !/usr/local/cuda-6.5/bin/nvcc -c PF_Gateway.cu -Xcompiler -fPIC -arch=sm_20 -I/usr/local/MATLAB/R2014b/extern/include -I/home/Desktop/Matlab_Package_for_Replication/nag_rng/include
        
        mex PF_Gateway.o  -output PF_cuda_QMC_crn_3VS -L/usr/local/cuda-6.5/lib64 -lcudart...
            -L/home/Desktop/Matlab_Package_for_Replication/nag_rng/lib_bin/linux -lnag_gpu_rng_D_Release -lnag_gpu_rng_S_Release
        
    case 'Windows'
        
        ! "C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v7.0\bin\nvcc"   -c   --cl-version 2010 -ccbin "C:\Program Files (x86)\Microsoft Visual Studio 10.0\VC\bin" PF_Gateway.cu  -I "C:\Program Files\MATLAB\R2014b\extern\include" -I "C:\Users\Desktop\Matlab_Package_for_Replication\nag_rng\include"
           
        mex PF_Gateway.obj  -output PF_cuda_QMC_crn_3VS -L"C:\Program Files\NVIDIA GPU Computing Toolkit\CUDA\v7.0\lib\x64" -lcudart...
        -L"C:\Users\Desktop\Matlab_Package_for_Replication\nag_rng\lib_bin\windows" -lnag_gpu_rng_D_Release -lnag_gpu_rng_S_Release
        
end

