#ifndef __PF_H__
#define __PF_H__

#include<math.h>

/*******************************************************
*Declaration of nag rng gpu fn's
******************************************************/

void nag_gpu_mrg32k3a_init(unsigned int *v1o, unsigned int *v2o, unsigned long long offset);

template <class FP>
void nag_gpu_mrg32k3a_normal(int nb, int nt, int np, FP *d_P);


template <class FP>
void nag_gpu_mrg32k3a_uniform(int nb, int nt, int np, FP *d_P);

/************************************************
*necessary class declarations
*****************************************/
//number of observations
const int N_VS = 3;

typedef double T;

template<class T>
struct particlevec
{
	int* NJumps;
    T* lambda;
    T* V;
    T* VJ;
	T* mu_States;
        T* V_States;
};

template<class T>
struct modelparam
{
        T* mu;
        T* muJ;
        T* sigmaJ;
        T* kappa;
        T* sigma;
        T* rho;
        T* beta;
        T* xi1;
        T* xi2;
        T* muV;
        T* muVQ;
        T* thetaV;
        T* kappaLambda;
        T* thetaLambda;
        T* sigmaLambda;
        T* muJQ;
        T* gammaV;
        T* gammaLambda;
        T* sigmav;

};

/************************************************
*function definitions
*****************************************/
									  
#include "arrayutil.cu"

#include "normlnpdf.cu"

#include "InitializeWeights.cu"

#include "GenerateParticles.cu"

#include "NewStatesMoments.cu"

#include "PreCompute_VSCoeff.cu"

#include "ComputeLinCoeffs.cu"

#include "ComputeObsMoments.cu"

#include "ComputeLikl.cu"

#include "Prediction.cu"

#include "SampleNewStates.cu"

#include "HandleWeights.cu"

#include "resample_get_indices.cu"

#include "resample.cu"

#include "PF.cu"

#endif
