function [res, filtersettings] = RunEst(prior_param, Nparam, Y, filtersettings, smcsettings)

% run density-tempered SMC 

% simulate from prior
X = PriorSim(prior_param, 30*Nparam);

lnpdf_prior = PriorLogl(X, prior_param);

keep = find(isfinite(lnpdf_prior));

X = X(keep(1:Nparam), :);

lnpdf_prior = lnpdf_prior(keep(1:Nparam));

% evaluate log likelihood at initial parameters
[l, filtersettings] = feval(filtersettings.filterfun, X, Y, filtersettings);

lnw = zeros(Nparam, 1);

gamma = 0;

t = 1;

tic

while (gamma < 1 )
    
    [res.ESS(t), res.normfac(t), res.AcceptRate(t,:), X, l, lnw, lnpdf_prior,...
         gamma, smcsettings, filtersettings] = SMC_Step(X, l, lnw, lnpdf_prior, prior_param,...
         gamma, Y, smcsettings, filtersettings);
            
     
    W = exp(lnw - max(lnw));
    
    W = W/sum(W);
    
    Xeven = Resample_vec(X, W, 10*Nparam);
    
    mean(Xeven)
    
    res.Xm(t, :) = mean(Xeven);
    
    res.X_prc5(t,:) = prctile(Xeven, 5);
    
    res.X_prc95(t,:) = prctile(Xeven, 95);
    
    res.runtime(t) = toc;

    if smcsettings.verbose    
        disp(['Time elapsed in sec ' num2str(res.runtime(t))]);
        disp(' ')
    end

    res.gamma(t) = gamma;
                    
    t = t+1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%store full-sample posterior%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
res.X = X;
res.W = W;


