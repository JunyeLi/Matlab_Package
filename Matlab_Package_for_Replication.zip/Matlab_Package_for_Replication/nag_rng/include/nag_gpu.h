/*
 *  Copyright 2009 Numerical Algorithms Group Ltd, Oxford, UK
 *  For use only within the terms of the licence agreement
 *  v0.2, 2009
 */

#ifndef _NAG_GPU_H_
#define _NAG_GPU_H_

#ifdef _WIN32
#   pragma warning( disable : 4996 ) // disable deprecated warning 
#endif

#define nag_gpu_utilCheckMsg(msg)           __nag_gpu_utilCheckMsg  (msg, __FILE__, __LINE__)
#define nag_gpu_utilSafeCall(err)           __nag_gpu_SafeCall      (err, __FILE__, __LINE__)

inline void __nag_gpu_utilCheckMsg( const char *errorMessage, const char *file, const int line )
{
  
  cudaError_t err = cudaGetLastError();
  if( cudaSuccess != err) {
    fprintf(stderr, "nag_gpu_utilCheckMsg CUDA error: %s in file <%s>, line %i : %s.\n",
            errorMessage, file, line, cudaGetErrorString( err) );
    exit(-1);
  }
#ifdef _DEBUG
  err = cudaThreadSynchronize();
  if( cudaSuccess != err) {
    fprintf(stderr, "nag_gpu_utilCheckMsg cudaThreadSynchronize error: %s in file <%s>, line %i : %s.\n",
            errorMessage, file, line, cudaGetErrorString( err) );
    exit(-1);
  }
#endif
  
}


// This function returns the best GPU (with maximum GFLOPS)
inline int nag_gpu_GetMaxGflopsDeviceId()
{

  int device_count = 0;
  cudaGetDeviceCount( &device_count );

  cudaDeviceProp device_properties;
  int max_gflops_device = 0;
  int max_gflops = 0;
	
  int current_device = 0;
  cudaGetDeviceProperties( &device_properties, current_device );
  max_gflops = device_properties.multiProcessorCount * device_properties.clockRate;
  ++current_device;

  while( current_device < device_count )
    {
      cudaGetDeviceProperties( &device_properties, current_device );
      int gflops = device_properties.multiProcessorCount * device_properties.clockRate;
      if( gflops > max_gflops )
        {
          max_gflops        = gflops;
          max_gflops_device = current_device;
        }
      ++current_device;
    }

    return max_gflops_device;
}


inline void __nag_gpu_SafeCall( cudaError err, const char *file, const int line )
{
  
  if( cudaSuccess != err) {
    fprintf(stderr, "nag_gpu_utilSafeCall Runtime API error in file <%s>, line %i : %s.\n",
            file, line, cudaGetErrorString( err) );
    exit(-1);
  }
  
}

#endif // _NAG_GPU_H_

/*
 *  Copyright 2009 Numerical Algorithms Group Ltd, Oxford, UK
 *  For use only within the terms of the licence agreement
 *  v0.2, 2009
 */
