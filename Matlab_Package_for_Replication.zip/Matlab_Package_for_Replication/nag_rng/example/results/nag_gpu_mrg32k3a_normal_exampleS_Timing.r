
 nag_gpu_mrg32k3a_normal single-precision example program

GPU time (No Greeks)  13.3 (ms) 
 sample/sec: 2.517178e+09 
 nag_gpu_mrg32k3a_normal single precision
CPU time (No Greeks) : 2800.0 msec
 sample/sec: 1.198373e+07 
 maximum absolute error GPU against CPU = 9.53674e-07 

GPU time (No Greeks)  19.7 (ms) 
 sample/sec: 1.703094e+09 
 nag_gpu_mrg32k3a_normal2 single precision
CPU time (No Greeks) : 2750.0 msec
 sample/sec: 1.220161e+07 
 maximum absolute error GPU against CPU = 9.53674e-07 


 Total number of N = 33554432 

 Number of points per thread = 1024 

 Number of threads per block = 64 

 Number of blocks = 512 

 offset = 1234 
