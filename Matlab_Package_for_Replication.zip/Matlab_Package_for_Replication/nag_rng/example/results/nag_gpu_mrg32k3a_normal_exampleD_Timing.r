
 nag_gpu_mrg32k3a_normal double-precision example program

GPU time (No Greeks)  53.8 (ms) 
 sample/sec: 6.234458e+08 
 nag_gpu_mrg32k3a_normal double precision
CPU time (No Greeks) : 3550.0 msec
 sample/sec: 9.451953e+06 
 maximum absolute error GPU against CPU = 8.88178e-16 

GPU time (No Greeks)  89.8 (ms) 
 sample/sec: 3.735054e+08 
 nag_gpu_mrg32k3a_normal2 double precision
CPU time (No Greeks) : 3430.0 msec
 sample/sec: 9.782633e+06 
 maximum absolute error GPU against CPU = 8.88178e-16 


 Total number of N = 33554432 

 Number of points per thread = 1024 

 Number of threads per block = 64 

 Number of blocks = 512 

 offset = 1234 
