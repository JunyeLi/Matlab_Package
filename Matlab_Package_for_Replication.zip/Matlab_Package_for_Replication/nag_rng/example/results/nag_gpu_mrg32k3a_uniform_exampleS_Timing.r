
 nag_gpu_mrg32k3a_uniform single-precision example program

GPU time (No Greeks)  9.6 (ms) 
 sample/sec: 3.487047e+09 
 nag_gpu_mrg32k3a_uniform single precision
CPU time (No Greeks) : 570.0 msec
 sample/sec: 5.886742e+07 
 maximum absolute error GPU against CPU = 0 

GPU time (No Greeks)  13.3 (ms) 
 sample/sec: 2.530128e+09 
 nag_gpu_mrg32k3a_uniform2 single precision
CPU time (No Greeks) : 470.0 msec
 sample/sec: 7.139241e+07 
 maximum absolute error GPU against CPU = 0 


 Total number of N = 33554432 

 Number of points per thread = 1024 

 Number of threads per block = 64 

 Number of blocks = 512 

 offset = 1234 
