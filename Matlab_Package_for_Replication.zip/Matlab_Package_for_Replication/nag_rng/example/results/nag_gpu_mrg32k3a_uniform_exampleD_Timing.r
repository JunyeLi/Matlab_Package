
 nag_gpu_mrg32k3a_uniform double-precision example program

GPU time (No Greeks)  11.2 (ms) 
 sample/sec: 3.000278e+09 
 nag_gpu_mrg32k3a_uniform double precision
CPU time (No Greeks) : 530.0 msec
 sample/sec: 6.331025e+07 
 maximum absolute error GPU against CPU = 0 

GPU time (No Greeks)  24.0 (ms) 
 sample/sec: 1.397861e+09 
 nag_gpu_mrg32k3a_uniform2 double precision
CPU time (No Greeks) : 420.0 msec
 sample/sec: 7.989150e+07 
 maximum absolute error GPU against CPU = 0 


 Total number of N = 33554432 

 Number of points per thread = 1024 

 Number of threads per block = 64 

 Number of blocks = 512 

 offset = 1234 
