
 nag_gpu_mrg32k3a_exponential single-precision example program

GPU time (No Greeks)  12.3 (ms) 
 sample/sec: 2.722132e+09 
 nag_gpu_mrg32k3a_exponential single precision
CPU time (No Greeks) : 2160.0 msec
 sample/sec: 1.553446e+07 
 maximum absolute error GPU against CPU = 9.53674e-07 

GPU time (No Greeks)  16.8 (ms) 
 sample/sec: 1.994067e+09 
 nag_gpu_mrg32k3a_exponential2 single precision
CPU time (No Greeks) : 2090.0 msec
 sample/sec: 1.605475e+07 
 maximum absolute error GPU against CPU = 9.53674e-07 


 Total number of N = 33554432 

 Number of points per thread = 1024 

 Number of threads per block = 64 

 Number of blocks = 512 

 offset = 1234 
