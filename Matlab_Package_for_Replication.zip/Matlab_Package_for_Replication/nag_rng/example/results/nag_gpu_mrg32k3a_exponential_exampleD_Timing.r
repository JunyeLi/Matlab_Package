
 nag_gpu_mrg32k3a_exponential double-precision example program

GPU time (No Greeks)  51.2 (ms) 
 sample/sec: 6.555653e+08 
 nag_gpu_mrg32k3a_exponential double precision
CPU time (No Greeks) : 3550.0 (ms)
 sample/sec: 9.451953e+06 
 maximum absolute error GPU against CPU = 1.77636e-15 

GPU time (No Greeks)  84.6 (ms) 
 sample/sec: 3.964552e+08 
 nag_gpu_mrg32k3a_exponential2 double precision
CPU time (No Greeks) : 3440.0 (ms)
 sample/sec: 9.754195e+06 
 maximum absolute error GPU against CPU = 1.77636e-15 


 Total number of N = 33554432 

 Number of points per thread = 1024 

 Number of threads per block = 64 

 Number of blocks = 512 

 offset = 1234 
