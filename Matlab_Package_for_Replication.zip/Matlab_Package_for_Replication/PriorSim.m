function X = PriorSim(prior_param, Nsample)
   
% 'mu','kappa','kappaLambda','thetaV','thetaLambda','sigma',
% 'sigmaLambda','xi1','xi2','muV','muVQ','beta','muJ','sigmaJ',...
% 'muJQ','rho','gammaV','gammaLambda','sigmav';

% use truncated normals on variables with positivity constraints, use normal
% on others

K = length(prior_param.mu);

X = zeros(Nsample, K);

index_p = [2:12, 14, 19];
index_n = [13, 15, 17, 18];

index_rho = 16;

index_u = 1;

for i = 1:length(index_p)
   
    Xi = prior_param.mu(index_p(i)) + prior_param.sig(index_p(i))*randn(Nsample*10, 1);
    
    keep = find(Xi > 0);
    
    X(:,index_p(i)) = Xi(keep(1:Nsample));    
        
end

for i = 1:length(index_n)
   
    Xi = prior_param.mu(index_n(i)) + prior_param.sig(index_n(i))*randn(Nsample*10, 1);
    
    keep = find(Xi < 0);
    
    X(:,index_n(i)) = Xi(keep(1:Nsample));    
        
end

Xi = prior_param.mu(index_rho) + prior_param.sig(index_rho)*randn(Nsample*10, 1);
keep = find(Xi > -1 & Xi < 1);
X(:, index_rho) = Xi(keep(1:Nsample));    

X(:, index_u) = repmat(prior_param.mu(index_u),Nsample,1)+repmat(prior_param.sig(index_u),Nsample,1).*randn(Nsample,length(index_u));








