clc;
clear;

randn('state',0);
rand('state',0);

%%true parameters
% drift
parstruct.mu = 0.04;

% Vol equation            
parstruct.kappa  = 6.00;
parstruct.thetaV = 0.01;
parstruct.sigma  = 2.50;
parstruct.muV    = 0.010;
parstruct.muVQ   = 0.015;
parstruct.xi1    = 2.00;

% lambda equation
parstruct.kappaLambda = 2.00;
parstruct.thetaLambda = 3.00;
parstruct.sigmaLambda = 0.60;
parstruct.beta        = 1.50;
parstruct.xi2         = 2.00;

% Jump params
parstruct.muJ    = -0.015;
parstruct.muJQ   = -0.018;
parstruct.sigmaJ =  0.002;

% leverage 
parstruct.rho  = -0.85;

% risk premia
parstruct.gammaV      = -0.05;
parstruct.gammaLambda = -0.20;

% maturities
tau = [1/12, 6/12, 12/12];

%measurement error
parstruct.sigmav = 0.002*ones(size(tau));

%% Auxiliary variables
param_fields = {'mu', 'kappa',  'kappaLambda', 'thetaV', 'thetaLambda',...
                'sigma', 'sigmaLambda', 'xi1', 'xi2', 'muV', 'muVQ', 'beta',...
                'muJ', 'sigmaJ', 'muJQ', 'rho', 'gammaV', 'gammaLambda', 'sigmav'};
    
clear param0;
            
for i = 1:length(param_fields)-1
    
    param0(i) = parstruct.(param_fields{i});
    
end     
param0 = [param0 parstruct.sigmav];

r  = 0.03;  % interest rate
dt = 1/252; % daily frequency

lnS0    = log(100);
V0      = parstruct.thetaV;
lambda0 = parstruct.thetaLambda;

%% run PF
% data simulation
simflag = 1;
 
if simflag == 1
    
    T = 2000;
    
    [lnS, Y, Vpath, Lambdapath, NJumppath, VJump] = SimModel_linmeas(parstruct, lnS0, V0, lambda0, T, dt, tau);
    
end

Nparticlesvec = 1024*[1/2, 1, 2, 4, 8, 16];

for iparticles = 1:length(Nparticlesvec)
    
    Nparticles = Nparticlesvec(iparticles);
    Nparticles
    
    Nparam = 128;
    
    % cuda pf settings
    PFOptions.nt = 64;
    PFOptions.nb = 512;
    
    PFOptions.nt_rng = 64;
    PFOptions.nb_rng = 512;
    
    PFOptions.offset = 0;
    
    PFOptions.seeds = [1 2 3 1 2 3];
    
    X = repmat(param0, Nparam, 1);
    
    % set param input to cuda pf
    for i = 1:length(param_fields)-1
        param.(param_fields{i}) = X(:, 1); X = X(:, 2:end);
    end
    
    param.sigmav = X;
    
    Particles.muStates = repmat([V0 lambda0], Nparam, 1);
    Particles.VStates  = zeros(Nparam, 2, 2);
    Particles.VStates(:, 1, 1) = 1e-10;
    Particles.VStates(:, 2, 2) = 1e-10;
    
    %% PF1: Particle Filter with smoothed likelihood estimate and pseudo random numbers
    disp('PF1: Smoothed LLH');
    tic
    [l1(:, :, iparticles), Particlesout1, ph1] = PF_cuda_Smooth_3VS(param, Particles, lnS, Y, PFOptions.nt,...
          PFOptions.nb, PFOptions.nt_rng, PFOptions.nb_rng, PFOptions.seeds, PFOptions.offset,dt, tau, Nparticles);
    
    runtime1(iparticles) = toc
    
    %% PF2: Particle Filter with smoothed likelihood estimate and Quasi-Monte-Carlo numbers
    p       = sobolset(4);
    qmc_set = p(1:Nparticles, :);
    
    disp('PF2: Smoothed LLH and QMC');
    tic
    [l2(:, :, iparticles), Particlesout2, ph2] = PF_cuda_QMC_3VS(param, Particles, lnS, Y, PFOptions.nt,...
          PFOptions.nb, PFOptions.nt_rng, PFOptions.nb_rng, PFOptions.seeds, PFOptions.offset, dt, tau, qmc_set);
        
    runtime2(iparticles) = toc
        
    %% PF3: Exact Particle Fitler  
    disp('PF3: Exact PF');
    
    Particles.NJumps = zeros(Nparam, Nparticles);
    Particles.V      = V0*ones(Nparam, Nparticles);
    Particles.lambda = lambda0*ones(Nparam, Nparticles);
    Particles.VJ     = zeros(Nparam, Nparticles);
    
    tic
    [l3(:, :, iparticles), Particlesout3, ph3] = PF_cuda_Exact_3VS(param, Particles, lnS, Y, PFOptions.nt,...
          PFOptions.nb, PFOptions.nt_rng, PFOptions.nb_rng, PFOptions.seeds, PFOptions.offset, dt, tau);
      
    runtime3(iparticles) = toc
       
end

%% Summary statistics
ll1 = sum(l1, 2);
ll1 = squeeze(ll1);

ll2 = sum(l2, 2);
ll2 = squeeze(ll2);

ll3 = sum(l3, 2);
ll3 = squeeze(ll3);

save llh_VS_final ll1 ll2 ll3 runtime1 runtime2 runtime3

disp('Mean and Standard Deviation of llh')
disp('Exact PF')
disp([mean(ll3)/1e3; std(ll3); runtime3/Nparam])
disp('Smoothed PF')
disp([mean(ll1)/1e3; std(ll1); runtime1/Nparam])
disp('QMC PF')
disp([mean(ll2)/1e3; std(ll2); runtime2/Nparam])



