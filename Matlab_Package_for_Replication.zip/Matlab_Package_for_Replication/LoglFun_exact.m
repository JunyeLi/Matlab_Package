function [l, filtersettings, Particles] = LoglFun_exact(X, Y, filtersettings)

Nparam = size(X, 1);

M = filtersettings.M;

% set param input to cuda pf
for i = 1:length(filtersettings.param_fields) - 1
    param.(filtersettings.param_fields{i}) = X(:, 1); X = X(:, 2:end);
end

param.sigmav = X*ones(1, filtersettings.N_VS);
  


Particles.NJumps = zeros(Nparam, M);
Particles.V      = filtersettings.V0*ones(Nparam, M);
Particles.lambda = filtersettings.lambda0*ones(Nparam, M);
Particles.VJ     = zeros(Nparam, M);



N_VS = filtersettings.N_VS;

FilterName = ['PF_cuda_Exact_' num2str(N_VS) 'VS'];

[l, Particles, filtersettings.offset] = feval(FilterName, param, Particles, Y.lnS, Y.VS,...
                        filtersettings.nt, filtersettings.nb, filtersettings.nt_rng,...
                        filtersettings.nb_rng, filtersettings.seeds, filtersettings.offset,...
                        filtersettings.dt, filtersettings.tau);
                                       
l = sum(l(:, filtersettings.burnin+1:end), 2);

l(~isfinite(l)) = -inf;
